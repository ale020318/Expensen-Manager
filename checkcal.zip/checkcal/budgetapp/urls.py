from django.urls import path
from . import views
from django.urls import path
from .views import budget_input, add_expense, summary, download_report

urlpatterns = [
    path('budget_input/', views.budget_input, name='budget_input'),
    path('add_expense/', views.add_expense, name='add_expense'),
    path('budget_input/', budget_input, name='budget_input'),
    path('add_expense/', add_expense, name='add_expense'),
    path('summary/', summary, name='summary'),
    path('download_report/', download_report, name='download_report'),
    
]
