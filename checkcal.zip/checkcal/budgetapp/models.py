from django.db import models

class MonthlyBudget(models.Model):
    month = models.CharField(max_length=50)
    budget_amount = models.DecimalField(max_digits=10, decimal_places=2)

class Expense(models.Model):
    budget = models.ForeignKey(MonthlyBudget, related_name='expenses', on_delete=models.CASCADE)
    title = models.CharField(max_length=100)
    amount_spent = models.DecimalField(max_digits=10, decimal_places=2)
    date = models.DateField()
