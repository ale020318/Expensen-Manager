from django.shortcuts import render, redirect
from .forms import MonthlyBudgetForm, ExpenseForm
from .models import MonthlyBudget
from django.http import HttpResponse
import csv
from .models import MonthlyBudget, Expense
import csv
from django.http import HttpResponse
from reportlab.pdfgen import canvas
from io import BytesIO



def budget_input(request):
    if request.method == 'POST':
        form = MonthlyBudgetForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('add_expense')
    else:
        form = MonthlyBudgetForm()
    return render(request, 'budget_input.html', {'form': form})

def add_expense(request):
    if request.method == 'POST':
        form = ExpenseForm(request.POST)
        if form.is_valid():
            expense = form.save(commit=False)
            expense.budget = MonthlyBudget.objects.last()  # Linking the last entered budget
            expense.save()
            return redirect('add_expense')  # Stay on the same page to add more expenses or change as needed
    else:
        form = ExpenseForm()
    return render(request, 'add_expense.html', {'form': form})




def summary(request):
    try:
        latest_budget = MonthlyBudget.objects.latest('id')
        expenses = Expense.objects.filter(budget=latest_budget)
        total_spent = sum(expense.amount_spent for expense in expenses)
        context = {
            'budget': latest_budget,
            'total_spent': total_spent,
            'expenses': expenses,
            'difference': latest_budget.budget_amount - total_spent
        }
    except MonthlyBudget.DoesNotExist:
        context = {
            'error': "No budget found."
        }
    return render(request, 'summary.html', context)


# def download_report(request):
#     # Fetch the latest budget and its expenses.
#     latest_budget = MonthlyBudget.objects.latest('id')
#     expenses = Expense.objects.filter(budget=latest_budget)

#     # Create the HttpResponse object with the appropriate CSV header.
#     response = HttpResponse(content_type='text/csv')
#     response['Content-Disposition'] = 'attachment; filename="report.csv"'

#     writer = csv.writer(response)
#     writer.writerow(['Month', 'Budget', 'Title', 'Amount Spent', 'Date'])

#     for expense in expenses:
#         writer.writerow([latest_budget.month, latest_budget.budget_amount, expense.title, expense.amount_spent, expense.date])

#     return response


def download_report(request):
    format_type = request.GET.get('format', 'csv')
    # Determine the format from the query parameters ('csv' or 'pdf')
    format_type = request.GET.get('format', 'csv')  # Default to 'csv'

    # Fetch the latest budget and its expenses.
    latest_budget = MonthlyBudget.objects.latest('id')
    expenses = Expense.objects.filter(budget=latest_budget)

    if format_type == 'csv':
        # Create the HttpResponse object with the appropriate CSV header.
        response = HttpResponse(content_type='text/csv')
        response['Content-Disposition'] = 'attachment; filename="report.csv"'

        writer = csv.writer(response)
        writer.writerow(['Month', 'Budget', 'Title', 'Amount Spent', 'Date'])

        for expense in expenses:
            writer.writerow([latest_budget.month, latest_budget.budget_amount, expense.title, expense.amount_spent, expense.date])

    elif format_type == 'pdf':
        # Create a byte stream buffer
        buf = BytesIO()
        # Create a canvas
        c = canvas.Canvas(buf)
        # Set a title for the document
        c.setTitle("Expense Report")
        # Set starting position
        y_position = 800
        # Write the headers
        c.drawString(70, y_position, "Month: " + str(latest_budget.month))
        c.drawString(70, y_position - 20, "Budget: " + str(latest_budget.budget_amount))
        c.drawString(70, y_position - 40, "Expenses:")

        # Adjust the position
        y_position -= 60

        # Loop through expenses and add them to the PDF
        for expense in expenses:
            c.drawString(70, y_position, f"Title: {expense.title}, Amount Spent: {expense.amount_spent}, Date: {expense.date}")
            y_position -= 20

            # Check to avoid writing off the page
            if y_position < 40:
                c.showPage()
                y_position = 800

        # Finish up the page and save the PDF
        c.showPage()
        c.save()
        # Move to the beginning of the BytesIO buffer
        buf.seek(0)
        # Create the HttpResponse object with the appropriate PDF header.
        response = HttpResponse(buf.getvalue(), content_type='application/pdf')
        response['Content-Disposition'] = 'attachment; filename="report.pdf"'
        # Clean up
    else:
         # If format_type is neither 'csv' nor 'pdf', return a simple error message.
            response = HttpResponse("Unsupported file format requested.", content_type='text/plain')
            response.status_code = 400  # Bad Request
    return response
