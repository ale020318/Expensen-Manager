from django.contrib import admin
from .models import MonthlyBudget, Expense

class ExpenseInline(admin.TabularInline):
    model = Expense
    extra = 1  # Specifies the number of blank forms the formset should display.

class MonthlyBudgetAdmin(admin.ModelAdmin):
    inlines = [
        ExpenseInline,
    ]
    list_display = ('month', 'budget_amount')  # Customize the list display on admin page
    search_fields = ['month']  # Enable search functionality based on month

class ExpenseAdmin(admin.ModelAdmin):
    list_display = ('title', 'budget', 'amount_spent', 'date')  # Customize the list display
    list_filter = ('budget', 'date')  # Enable filtering by these fields
    search_fields = ['title', 'budget__month']  # Enable search functionality

# Register your models here.
admin.site.register(MonthlyBudget, MonthlyBudgetAdmin)
admin.site.register(Expense, ExpenseAdmin)
