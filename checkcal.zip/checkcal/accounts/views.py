from django.shortcuts import render, redirect
from django.contrib.auth import login, authenticate, logout
from .forms import CustomUserCreationForm
from django.shortcuts import render
from django.shortcuts import render, redirect
from django.contrib.auth import login
from django.contrib.auth.decorators import login_required, user_passes_test
from .forms import CustomUserCreationForm, AdvisorRegistrationForm
from .models import CustomUser
from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login
from django.contrib import messages
from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.contrib.auth.decorators import login_required, user_passes_test
from django.shortcuts import redirect
from django.contrib import messages



# Assuming other imports and views are already here

def home(request):
    return render(request, "home.html")

def list_advisor(request):
    return render(request, "list_advisor.html")

def list_advisor1(request):
    return render(request, "list_advisor1.html")

def list_advisor2(request):
    return render(request, "list_advisor2.html")

def list_advisor3(request):
    return render(request, "list_advisor3.html")

def list_advisor4(request):
    return render(request, "list_advisor4.html")

def list_advisor5(request):
    return render(request, "list_advisor5.html")

def list_advisor6(request):
    return render(request, "list_advisor6.html")

def list_advisor7(request):
    return render(request, "list_advisor7.html")

def list_advisor8(request):
    return render(request, "list_advisor8.html")

def register_request(request):
    if request.method == "POST":
         form = AdvisorRegistrationForm(request.POST)
         if form.is_valid():
            form.save()
            return redirect("home")
    else:
        form = CustomUserCreationForm()
    return render(request, "register.html", {"form": form})

def login_request(request):
    if request.method == "POST":
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            return redirect("home")
        else:
            return render(request, "login.html", {"error": "Invalid username or password"})
    return render(request, "login.html")

def logout_request(request):
    logout(request)
    return render(request, "login.html")

def register_advisor(request):
    if request.method == 'POST':
        form = AdvisorRegistrationForm(request.POST)
        if form.is_valid():
            user = form.save(commit=False)
            user.is_advisor = True
            user.is_approved = False  # Advisors need approval
            user.save()
            # Optionally, login the advisor here or redirect to a waiting page
            return render(request, 'home.html')  # Redirect them to a waiting for approval page
    else:
        form = AdvisorRegistrationForm()
    return render(request, 'register_advisor.html', {'form': form})



def is_admin_user(user):
    return user.is_authenticated and user.is_superuser

def is_staff(user):
    return user.is_staff

@login_required
@user_passes_test(is_staff)
def approve_advisors(request):
    if request.method == 'POST':
        # Assuming you're sending advisor IDs to approve through POST request
        advisor_ids = request.POST.getlist('advisor_ids')
        CustomUser.objects.filter(id__in=advisor_ids).update(is_approved=True)
        return redirect('admin_dashboard')  # Redirect to an admin dashboard or advisor list

    # List unapproved advisors
    unapproved_advisors = CustomUser.objects.filter(is_advisor=True, is_approved=False)
    return render(request, 'approve_advisors.html', {'advisors': unapproved_advisors})


def advisor_login(request):
    if request.method == "POST":
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(request, username=username, password=password)
        
        if user is not None and user.is_advisor:
            if user.is_approved:
                login(request, user)
                # Use the name of the URL pattern for the advisor dashboard here
                return redirect('advisor_dashboard')
            else:
                messages.error(request, "Your advisor account is not yet approved.")
                return redirect('advisor_login')
        else:
            messages.error(request, "Invalid login credentials.")
            return redirect('advisor_login')
    
    return render(request, "login12.html")


@login_required
def advisor_dashboard(request):
    # Existing checks for advisor and approval
    meeting_notification = request.session.get('meeting_notification', False)
    if meeting_notification:
        # Optionally, clear the notification from the session after displaying it
        del request.session['meeting_notification']
    return render(request, "advisor_dashboard.html", {'meeting_notification': meeting_notification})



def notify_meeting(request):
    # You can use a session variable, a database flag associated with the user, or any other mechanism
    request.session['meeting_notification'] = True
    messages.info(request, 'There is a meeting scheduled.')
    return redirect('advisor_dashboard')  # Redirect back to the advisor dashboard    
    