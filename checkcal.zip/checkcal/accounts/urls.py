from django.urls import path
from . import views

urlpatterns = [
    path('register/', views.register_request, name='register'),
    path('list/', views.list_advisor, name='list_advisor'),
    path('login/', views.login_request, name='login'),
    path('logout/', views.logout_request, name='logout'),
     path('', views.home, name='home'),
     path('advisor/register/', views.register_advisor, name='register_advisor'),
     path('advisor/dashboard/', views.advisor_dashboard, name='advisor_dashboard'),
     path('advisor/login/', views.advisor_login, name='advisor_login'),
     path('admin/approve_advisors/', views.approve_advisors, name='approve_advisors'),
     path('advisor-dashboard/notify-meeting/', views.notify_meeting, name='notify_meeting'),
     path('list1', views.list_advisor1, name='register1'),
     path('list2', views.list_advisor2, name='register2'),
     path('list3', views.list_advisor3, name='register3'),
     path('list4', views.list_advisor4, name='register4'),
     path('list5', views.list_advisor5, name='register5'),
     path('list6', views.list_advisor6, name='register6'),
     path('list7', views.list_advisor7, name='register7'),
     path('list8', views.list_advisor8, name='register8'),
     
]
