from django.urls import path
from . import views

urlpatterns = [
    # Your other URL patterns here
    path('send_email/', views.send_user_email, name='send_user_email'),
    # Assuming you have a home view
]