

from django.core.mail import send_mail
from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.contrib import messages

def generate_google_meet_link():
    # Placeholder function - in a real application, implement the logic to generate/fetch a Google Meet link
    # For demonstration, we'll just return a dummy link
    return "https://meet.google.com/vyj-vnrw-nny"

@login_required
def send_user_email(request):
    user_email = request.user.email
    google_meet_link = generate_google_meet_link()
    send_mail(
        'Thank You for Your Appointment Booking',
        'Dear Sir/madam,\n\n'
        'Thank you for booking your appointment with us. We re looking forward to meeting you and discussing your needs.'
        'Please join us at the scheduled time by clicking on the following Google Meet link: https://meet.google.com/new-dummy-link'
        'If you have any questions before our meeting, feel free to reach out.\n\n'
        'Best regards,\n'
        'lincy\n'
        'co-founder\n'
        '+91-92xxxxxxxx.\n',
        'from@example.com',
        [user_email],
        fail_silently=False,
    )
    messages.success(request, "Email sent successfully!")
    return render(request, 'email_sent.html')

