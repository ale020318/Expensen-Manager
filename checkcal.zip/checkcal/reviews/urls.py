from django.urls import path
from .views import review_and_add,about  # Ensure this is correctly imported

urlpatterns = [
    path('reviews/', review_and_add, name='review_and_add'),
    path('about/', about, name='about'),# Adjust the path as needed
]