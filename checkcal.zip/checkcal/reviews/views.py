from django.shortcuts import render, redirect
from .forms import ReviewForm  # Ensure you have imported the correct form class
from .models import Review

def review_and_add(request):
    if request.method == 'POST':
        form = ReviewForm(request.POST)
        if form.is_valid():
            review = form.save(commit=False)
            review.author = request.user
            review.save()
            return redirect('review_and_add')  # Redirect back to the same page
    else:
        form = ReviewForm()
    
    reviews = Review.objects.all()
    return render(request, 'add_review.html', {'reviews': reviews, 'form': form})

def about(request):
    return render(request, "about.html")
